# TIK DZ (Android)
Get the APK via GitHub: create a repo, upload all files (keep the .github folder), open
Actions > Build APK > latest run > Artifacts > TikDZ-apk. Unzip it and install app-debug.apk.
Or build locally: open in Android Studio (JDK 17) and Run.
UI: app/src/main/assets/index.html
